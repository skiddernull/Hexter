----------------------
=Hexter.exe=
----------------------
Made By Minhgotuknight19

Created: March 21 2024
Made In C++
Dont RUN your PC

This Is Non-Safety Run Malware

I Was Planning to add delete username

-------------------------------------------------------

 GLITCH SKULL Name means:

  Hexter

  -------------------
----  -----------  -----
--     ---------    ---
---   -----------  -----
 ----------------------
  ---  ----  ----  ----
  ---  ---   ---   ---
  ---  ---  ----   ----
-------------------------------------------------------

scroll down :)



scroll down :\





scroll down :/




scroll down :|









Hi I am Wynn and Yedb0y33k